import { RegexCharactersEnum } from './types';
export declare const regexCharacters: RegexCharactersEnum;
