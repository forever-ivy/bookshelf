import { NamedStyles } from './namedStyles';
import { NormalStyles } from './normalStyles';
import { NumberedStyles } from './numberedStyles';
declare const formaters: (typeof NamedStyles | typeof NormalStyles | typeof NumberedStyles)[];
export default formaters;
