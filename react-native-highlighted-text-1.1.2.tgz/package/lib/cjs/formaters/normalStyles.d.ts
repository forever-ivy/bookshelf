import type { FormaterBase, FormaterCreation } from './formaterBase';
import type { GenerateRegex, HighlightedTextStyles, OnPressHighlighted } from '../types';
export declare class NormalStyles implements FormaterBase {
    readonly styles: HighlightedTextStyles;
    readonly regex: ReturnType<GenerateRegex>;
    readonly pressFunctions: OnPressHighlighted;
    private currentStyle;
    constructor(styles: HighlightedTextStyles, regex: ReturnType<GenerateRegex>, pressFunctions: OnPressHighlighted);
    validate(text: string): boolean;
    create(text: string): FormaterCreation;
    private getStyle;
}
