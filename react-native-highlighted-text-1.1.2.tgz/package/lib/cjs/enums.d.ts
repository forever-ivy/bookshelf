export declare const Character: {
    readonly SQUARE_BRACKETS: "square-brackets";
    readonly CURLY_BRACKETS: "curly-brackets";
    readonly TAGS: "tags";
    readonly PARENTHESIS: "parenthesis";
};
