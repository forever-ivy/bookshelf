import type { GenerateRegex } from './types';
export declare const generateRegex: GenerateRegex;
