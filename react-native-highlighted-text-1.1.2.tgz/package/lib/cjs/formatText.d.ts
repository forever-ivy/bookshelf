import type { FormatText } from './types';
export declare const formatText: FormatText;
